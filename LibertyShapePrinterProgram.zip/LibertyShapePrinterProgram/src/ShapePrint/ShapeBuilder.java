package ShapePrint;
import java.util.*;
import java.util.Scanner;

public class ShapeBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		String shape;
		int height = 0;
		String label;
		String rows;
		int row = 0;
		boolean answer = true;
		
		while (answer == true) {
			boolean answer2 = true;
			
			System.out.print("What shape should I draw (Triangle, Square, or Diamond)? ");
			shape = s.nextLine();
			shape.toLowerCase();
			while (!shape.equals("triangle") && !shape.equals("square") && !shape.equals("diamond")) {
				System.out.print("Error! Invalid Shape! Try Again. ");
				shape = s.nextLine();
				shape.toLowerCase();
			}
			
			System.out.printf("How tall should the %s be? ", shape);
			boolean check = true;
			while(check == true) {
				try {
					height = s.nextInt();
					check = false;
					if (height < 4) {
						System.out.print("Error! Height is too short! "
								+ "Please enter a number of four or higher! ");
						s.nextInt();
					}
				} catch (Exception e) {
					System.out.print("I'm sorry, I didn't understand that, "
							+ "please enter a positive integer. ");
					s.next();
					check = true;
				}
			}
			
			System.out.printf("What label should I print on this %s "
					+ "(Leave Blank for LU)? ", shape);
			s.nextLine();
			label = s.nextLine();
			if (label.isEmpty()) {
				label = "LU";
			} 
			while(label.length() > height) {
				System.out.printf("Error! The %s doesn't have a "
						+ "row that can fit the label! Try Again! ", shape);
				label = s.nextLine();
				if (label.isEmpty()) {
					label = "LU";
				} 
			}
			
			System.out.printf("On what row should I print %s? ", label);
			rows = s.nextLine();
			if(rows.isEmpty()) {
				row = 4;
			} else {
				boolean error = true;
				while (error == true) {
					try {
						row = Integer.parseInt(rows);
						error = false;
					} catch (NumberFormatException e) {
						System.out.print("Error! Invalid Input! "
								+ "Please Enter a Positive Integer! ");
						rows = s.nextLine();
						if(rows.isEmpty()) {
							row = 4;
						}
						error = true;
					}
				}
			}
			while (row < 1 || row < label.length() 
					|| row > height) {
				if (row < 1 || row > height) {
					System.out.print("Error! Row does not exist! "
							+ "Please select a different row! ");
					rows = s.nextLine();
					if(rows.isEmpty()) {
						row = 4;
					} else {
						boolean error = true;
						while (error == true) {
							try {
								row = Integer.parseInt(rows);
								error = false;
							} catch (NumberFormatException e) {
								System.out.print("Error! Invalid Input! "
										+ "Please Enter a Positive Integer! ");
								rows = s.nextLine();
								if(rows.isEmpty()) {
									row = 4;
								}
								error = true;
							}
						}
					}
				} else {
					if (shape.equals("triangle") || shape.equals("diamond")) {
						System.out.printf("The row you selected does not "
								+ "have enough space for %s within the %s! "
								+ "Please select a different row! ", label, shape);
						rows = s.nextLine();
						if(rows.isEmpty()) {
							row = 4;
						} else {
							boolean error = true;
							while (error == true) {
								try {
									row = Integer.parseInt(rows);
									error = false;
								} catch (NumberFormatException e) {
									System.out.print("Error! Invalid Input! "
											+ "Please Enter a Positive Integer! ");
									rows = s.nextLine();
									if(rows.isEmpty()) {
										row = 4;
									}
									error = true;
								}
							}
						}
					}
				}
			}
			
			if(shape.equals("square")) {
				printsquare(height, row, label);
			} else if (shape.equals("triangle")) {
				printtriangle(height, row, label);
			} else if (shape.equals("diamond")) {
				printdiamond(height, row, label);
			}
			answer = checkdone(s);
		}
		s.close();
		System.exit(0);

	}
	
	public static void printtriangle( int height, int row, String label) {
		
		for (int i = 0; i < height; i++) {
			int count = 0;
			for (int j = 0; j < (height - 1) -i; j++) {
					System.out.print(" ");
			}
			while (count <= i) {
				if ((i+1) == row){
					int num = row - label.length();
					int beforenafter = (int) Math.ceil((double)num/2);
					int c = 0;
					char[] str = label.toCharArray();
					for (int k = 0; k < row; k++) {
						if (k >= beforenafter && k < (row - beforenafter)) {
							System.out.printf("%c ", str[c]);
							c++;
						} else {
							System.out.print("X ");
						}
					}
					count = i + 1;
				} else {
					System.out.print("X ");
					count++;
				}
			}
			System.out.println();
		}
	}
	
	public static void printdiamond(int height, int row, String label) {
		for (int i = 0; i < height; i++) {
			int count = 0;
			for (int j = 0; j < (height - 1) - i; j++) {
				System.out.print(" ");
			}
			while (count <= i) {
				if ((i+1) == row){
					int num = row - label.length();
					int beforenafter = (int) Math.ceil((double)num/2);
					int c = 0;
					char[] str = label.toCharArray();
					for (int k = 0; k < row; k++) {
						if (k >= beforenafter && k < (row - beforenafter)) {
							System.out.printf("%c ", str[c]);
							c++;
						} else {
							System.out.print("X ");
						}
					}
					count = i + 1;
				} else {
					System.out.print("X ");
					count++;
				}
			}
			System.out.println();
		}
		for (int i = (height -1); i > 0; i--) {
			int count = 1;
			for(int j = (height)-i; j> 0; j--) {
				System.out.print(" ");
			}
			while (count <= i) {
				if ((i+1) == row +1) {
					int num = row - label.length();
					int beforenafter = (int) Math.ceil((double)num/2);
					int c = 0;
					char[] str = label.toCharArray();
					for (int k = 0; k < row; k++) {
						if (k >= beforenafter && k < (row - beforenafter)) {
							System.out.printf("%c ", str[c]);
							c++;
						} else {
							System.out.print("X ");
						}
					}
					count = i + 1;
				} else {
					System.out.print("X ");
					count++;
				}
			}
			System.out.println();
		}
	}
	
	public static void printsquare(int height, int row, String label) {
		for (int i = 0; i < height; i++) {
			if ((i+1) == row) {
				int num = height - label.length();
				int beforenafter = (int) Math.ceil((double)num/2);
				int c = 0;
				char[] str = label.toCharArray();
				for (int j = 0; j < height; j++) {
					if (height %2 == 0 && label.length() %2 == 0
							|| height %2 != 0 && label.length() %2 != 0) {
						if (j >= beforenafter && j <= (height - beforenafter)
								&& c < label.length()) {
							System.out.printf("%c ", str[c]);
							c++;
						} else {
							System.out.print("X ");
						}
					} else {
						if (j >= beforenafter-1 && j <= (height - beforenafter)
								&& c < label.length()) {
							System.out.printf("%c ", str[c]);
							c++;
						} else {
							System.out.print("X ");
						}
					}
				}
			} else {
				for (int j = 0; j < height; j++) {
					System.out.print("X ");
				}
			}
			System.out.println();
		}
	}
	
	public static boolean checkdone(Scanner s) {
		String ans;
		boolean answer = true;
		boolean answer2 = true;
		System.out.print("Would you like me to print another shape? ");
		ans = s.nextLine();
		ans.toLowerCase();
		while (answer2 == true) {
			if (ans.equals("yes") || ans.equals("y")) {
				answer2 = false;
				answer = true;
			} else if (ans.equals("no") || ans.equals("n")) {
				answer2 = false;
				answer = false;
			} else {
				System.out.print("Invalid Answer! Please Try Again! ");
				ans = s.nextLine();
			}
		}
		return answer;
	}

}
